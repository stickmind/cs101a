from stanfordkarel import *

"""
File: FillRowKarel.py
---------------------
Karel lays down a whole row of beepers.
BUGGY -- off by one bug
Need to add a final put_beeper()
"""


def main():
    while front_is_clear():
        put_beeper()
        move()


# There is no need to edit code beyond this point

from pathlib import Path


def get_word_file():
    current_file = Path(__file__)

    word_file = (
        Path(__file__).absolute().parent
        / "worlds"
        / current_file.with_suffix(".w").name
    )

    return str(word_file) if word_file.is_file() else ""


if __name__ == "__main__":
    run_karel_program(get_word_file())
