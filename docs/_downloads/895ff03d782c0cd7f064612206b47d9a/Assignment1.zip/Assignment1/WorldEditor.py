from stanfordkarel.world_editor import *

if __name__ == "__main__":
	run_world_editor()
